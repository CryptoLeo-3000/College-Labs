package com.example.web_scrape_population

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
