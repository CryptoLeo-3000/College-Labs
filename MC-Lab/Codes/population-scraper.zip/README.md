# web_scrape_population

from the tutorial to scrape web data to display population
