import 'package:flutter/material.dart';
import 'package:flutterapp/gkquiz2app/generatedmainwidget/GeneratedMainWidget.dart';
import 'package:flutterapp/gkquiz2app/generatedhowtoplaywidget/GeneratedHowtoPlayWidget.dart';
import 'package:flutterapp/gkquiz2app/generatedsuccesswidget/GeneratedSuccessWidget.dart';
import 'package:flutterapp/gkquiz2app/generatedstartwidget/GeneratedStartWidget.dart';
import 'package:flutterapp/gkquiz2app/generatedstartbuttonpressedwidget/GeneratedStartButtonpressedWidget.dart';
import 'package:flutterapp/gkquiz2app/generatedq1wronganswerwidget/GeneratedQ1WrongAnswerWidget.dart';
import 'package:flutterapp/gkquiz2app/generatedretrybuttonwidget2/GeneratedRetryButtonWidget2.dart';
import 'package:flutterapp/gkquiz2app/generatedq1widget/GeneratedQ1Widget.dart';
import 'package:flutterapp/gkquiz2app/generatedoptionawidget1/GeneratedOptionaWidget1.dart';
import 'package:flutterapp/gkquiz2app/generatedoptionbwidget1/GeneratedOptionbWidget1.dart';
import 'package:flutterapp/gkquiz2app/generatedoptioncwidget1/GeneratedOptioncWidget1.dart';
import 'package:flutterapp/gkquiz2app/generatedoptiondwidget1/GeneratedOptiondWidget1.dart';
import 'package:flutterapp/gkquiz2app/generatedq1rightanswerwidget/GeneratedQ1RightAnswerWidget.dart';

void main() {
  runApp(Gkquiz2App());
}

class Gkquiz2App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedMainWidget',
      routes: {
        '/GeneratedMainWidget': (context) => GeneratedMainWidget(),
        '/GeneratedHowtoPlayWidget': (context) => GeneratedHowtoPlayWidget(),
        '/GeneratedSuccessWidget': (context) => GeneratedSuccessWidget(),
        '/GeneratedStartWidget': (context) => GeneratedStartWidget(),
        '/GeneratedStartButtonpressedWidget': (context) =>
            GeneratedStartButtonpressedWidget(),
        '/GeneratedQ1WrongAnswerWidget': (context) =>
            GeneratedQ1WrongAnswerWidget(),
        '/GeneratedRetryButtonWidget2': (context) =>
            GeneratedRetryButtonWidget2(),
        '/GeneratedQ1Widget': (context) => GeneratedQ1Widget(),
        '/GeneratedOptionaWidget1': (context) => GeneratedOptionaWidget1(),
        '/GeneratedOptionbWidget1': (context) => GeneratedOptionbWidget1(),
        '/GeneratedOptioncWidget1': (context) => GeneratedOptioncWidget1(),
        '/GeneratedOptiondWidget1': (context) => GeneratedOptiondWidget1(),
        '/GeneratedQ1RightAnswerWidget': (context) =>
            GeneratedQ1RightAnswerWidget(),
      },
    );
  }
}
